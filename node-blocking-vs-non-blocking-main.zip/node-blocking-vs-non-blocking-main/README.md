# node-blocking-vs-non-blocking
Un pequeño demo para explicar la diferencia

Esto es parte de mi curso de Node: de cero a experto que puedes encontrar aquí

[Node: de cero a experto](https://fernando-herrera.com/#/curso/node-cero-experto)
